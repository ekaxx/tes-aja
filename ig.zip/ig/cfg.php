<?php


$apikey = "eyemrefreeJpc3MiOiJ0b3B0YWwuY29tIiwiGXhwIjoxNDI2NDIwODAwLCJodHwdGFsLmNvbS9qd21wYW55IioiVGJ1ZzX1";

$i_id = "51379060976";

$dID = "082ecaaddf069661";
